x = 5
y = 2.5
z = x + y

print (z)