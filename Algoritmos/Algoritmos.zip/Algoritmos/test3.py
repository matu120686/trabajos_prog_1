name = "Ana"
age = 25
print(f"{name} tiene {age} años")