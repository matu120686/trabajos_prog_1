
precio = 19.99
cantidad = 3
total = precio * cantidad

print( f"El total es: ", total)